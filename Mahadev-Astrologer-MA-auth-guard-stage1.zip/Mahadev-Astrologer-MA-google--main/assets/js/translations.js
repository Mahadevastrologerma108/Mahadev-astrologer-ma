window.commonTranslations = {
    en: {
        // ===== NAV & ZODIAC =====
        nav_home: "Home", nav_horoscope: "Horoscope", nav_panchang: "Panchang", nav_guide: "Update", nav_book: "Book Now",nav_sound: "Sound Healing",nav_tools: "Vedic Tools",number_tool: "Numerology",nav_shop: "Shop",
        finder_title: "🔱 Identify Your Zodiac (Rashi Finder)",
        finder_name_label: "By First Letter of Name:",
        finder_date_label: "By Date & Month of Birth:",
        finder_select: "Select...",
        finder_divider: "OR",
       "guide_subtitle": "Ancient Wisdom for Modern Life",
       "hero_mantra": "Nada, Health, and Time — The Triad of Shiva",
       "hero_tagline": "\"Melody, Health, and Stars — All by the grace of Mahadev\"",
       "hero_desc": "Welcome to Mahadev Astrologer MA. Get expert Vedic Astrology, Ayurveda remedies, and spiritual healing. Discover your destiny with us.",
        
        player_title: "Divine Anthem 🔱", player_subtitle: "Coming Soon: Healing Sounds by Parth", player_msg: "The Divine Melody is being tuned. Coming Soon! 🚩",

        // Trust Building Section (User Benefits)
        "trust_title": "Why Trust Mahadev Astrologer?",
        "trust_pdf": "✨ <strong>Free PDF Reports:</strong> Get your complete consultation report in PDF format at no extra cost.",
        "trust_privacy": "🛡️ <strong>100% Privacy:</strong> Your personal data and birth details are handled with utmost confidentiality.",
        "trust_connect": "💬 <strong>Direct Connection:</strong> Connect with us via WhatsApp, Telegram, or Email as per your comfort.",
        "trust_transparent": "📋 <strong>Transparent Process:</strong> No hidden fees. What you see is what you pay.",

        // Unlock Divine Secrets Section
        "unlock_title": "Unlock the Divine Secrets",
        "unlock_sub": "Infinite wisdom of Mahadev's creations",
        "store_title": "Divine Astro Store",
        "store_desc_en": "Authentic Lab-certified Gemstones, Nepal Rudraksha, and FSSAI approved Vedic Herbs. Every product is energized.",
        "btn_explore_store": "Explore Store ➔",
        "nav_vastu": "Vastu Shastra Consultation",
        "idx_vastu_desc_en": "Transform your space with 16-Zone Energy Balancing and modern No-Demolition Vedic Remedies.",
        "btn_learn_more": "REQUEST AUDIT ➔",
        // Divine Bot
        "bot_welcome": "Pranaam! I am Mahadev Astrologer MA's assistant. How can I help you with your Horoscope or queries?",
        "ph_bot_input": "Type your question...",
        
        "ins_swapna_title": "Swapna Fal (Dream Meaning)",
        "ins_swapna_desc": "Decode the hidden cosmic messages of your dreams according to Vedic Swapna Shastra.",
        "ins_mantra_title": "Vedic Mantras",
        "ins_mantra_desc": " For peace and spiritual grace chant daily these shiddh mantras.",
        "btn_read": "Read Now",

        ph_name_input: "Your Full Name", ph_wa_input: "WhatsApp Number", ph_city_input: "Birth City/Place",
        ph_m_name_input: "Male Name", ph_f_name_input: "Female Name", btn_submit: "Invoke Divine Guidance",
        rel_label: "Information for?", rel_self: "Self", rel_father: "Father", rel_mother: "Mother", rel_spouse: "Spouse", rel_child: "Child", rel_other: "Other / Friend",

        title_terms: "Terms & Conditions | Mahadev Astrologer MA",
        terms_title: "Terms & Conditions",
        terms_intro: "By accessing and using the services of Mahadev Astrologer MA, you agree to comply with the following terms and conditions:",

        site_title: "Mahadev Astrologer MA | Divine Vedic Wisdom",
        btn_install: "INSTALL MAHADEV ASTROLOGER MA APP",
        hero_sub: "ESTABLISHED VEDIC LINEAGE",
        hero_title: "Discover the Truth of Your Destiny",
        hero_desc: "Authentic Vedic Astrology and precise remedial solutions by Mahadev Astrologer MA.", 
        "guide_title": "Latest Divine Guide",

        event_tag: "Holi 2026",
        event_text: "🔱 Holi Muhurat & Rituals",
        event_url: "https://www.mahadevastrologerma.in/latest-guide/article.html?id=6408606802958228263",

        svc_kundli_title: "Kundali Making", svc_kundli_desc: "Detailed birth chart analysis and planetary insights.",
        svc_matching_title: "Kundali Matching", svc_matching_desc: "Guna Milan and compatibility for a blessed marriage.",
        svc_combo_title: "Combo Analysis", svc_combo_desc: "Complete Kundali + Palmistry report on your WhatsApp.",
    
        badge_best: "BEST VALUE", svc_palm_title: "Palmistry Analysis", svc_palm_desc: "In-depth study of palm lines for future guidance.",
        svc_num_title: "Numerology", svc_num_desc: "Success through numbers and vibrational analysis.",

        ins_horo_title: "Daily Horoscope", ins_horo_desc: "Discover what the stars have in store for you today.",
        nav_articles: "Divine Articles", articles_desc: "A collection of Vedic stories and spiritual wisdom.",
        ins_panchang_desc: "Check tithi, nakshatra, and auspicious timings for your day",
        ins_panchang_title: "Today's Pannchang",


        btn_view: "VIEW DETAILS →", btn_read: "READ NOW →", btn_explore: "EXPLORE", btn_invoke: "Start Consultation", btn_send: "Submit",
        form_title: "Consult with Mahadev Astrologer MA", lbl_select_service: "SELECT YOUR SERVICE",
        opt_kundli: "Kundali Making (₹501)", opt_match: "Kundali Matching (₹601)", opt_palm: "Palmistry Analysis (₹501)", opt_num: "Numerology Report (₹251)", opt_combo: "♻️ Combo: Kundali + Palm (₹701)",

        lbl_privacy: "PRIVACY & CONTACT PREFERENCE:", lbl_uid: "Client UID (To keep your details secure)",
        lbl_male_details: "👦 Male Details", lbl_female_details: "👧 Female Details",
        palm_note: "✋ Note: Keep clear photos of both sides of your both palms ready.",
        email_note: "⚠️ Note: Email response might be slower.",
        ph_name: "Enter Your Full Name", ph_contact: "WhatsApp / Telegram Number", ph_city: "Birth City/Place", ph_feedback: "Share your experience here...",
        testi_title: "🔱 Client Testimonials", feedback_heading: "Your Feedback is Valuable",

        // ===== PLANETS & HOUSES =====
        planet_sun: "Sun (Surya)", planet_moon: "Moon (Chandra)", planet_mars: "Mars (Mangal)", planet_mercury: "Mercury (Budh)", planet_jupiter: "Jupiter (Guru)", planet_venus: "Venus (Shukra)", planet_saturn: "Saturn (Shani)", planet_rahu: "Rahu", planet_ketu: "Ketu",
        house_1: "1st House (Self/Physical)", house_2: "2nd House (Wealth/Family)", house_3: "3rd House (Siblings/Courage)", house_4: "4th House (Mother/Happiness)", house_5: "5th House (Children/Wisdom)", 
        house_6: "6th House (Debt/Enemies)", house_7: "7th House (Marriage/Partner)", house_8: "8th House (Longevity/Secrets)", house_9: "9th House (Luck/Dharma)", house_10: "10th House (Career/Karma)", 
        house_11: "11th House (Income/Gains)", house_12: "12th House (Losses/Spirituality)",

        // ===== NAKSHATRA & YOGA =====
       "nak_01": "Ashwini", "nak_02": "Bharani", "nak_03": "Krittika", "nak_04": "Rohini", "nak_05": "Mrigashira",
        "nak_06": "Ardra", "nak_07": "Punarvasu", "nak_08": "Pushya", "nak_09": "Ashlesha", "nak_10": "Magha",
        "nak_11": "Purva Phalguni", "nak_12": "Uttara Phalguni", "nak_13": "Hasta", "nak_14": "Chitra", "nak_15": "Swati",
        "nak_16": "Vishakha", "nak_17": "Anuradha", "nak_18": "Jyeshtha", "nak_19": "Mula", "nak_20": "Purva Ashadha",
        "nak_21": "Uttara Ashadha", "nak_22": "Shravana", "nak_23": "Dhanishta", "nak_24": "Shatabhisha", "nak_25": "Purva Bhadrapada",
        "nak_26": "Uttara Bhadrapada", "nak_27": "Revati",
        yoga_gajkesari: "Gajkesari Yoga", yoga_budhaditya: "Budhaditya Yoga", yoga_shasha: "Shasha Yoga", yoga_malavya: "Malavya Yoga", yoga_hamsa: "Hamsa Yoga", yoga_bhadra: "Bhadra Yoga", yoga_ruchaka: "Ruchaka Yoga", yoga_laxmi: "Laxmi Yoga",
        dosha_mangal: "Mangal Dosha", dosha_kaal_sarp: "Kaal Sarp Dosha", dosha_pitar: "Pitar Dosha",

        // ===== NUMEROLOGY & YOGINI =====
        num_1: "Number 1 (Sun)", num_2: "Number 2 (Moon)", num_3: "Number 3 (Jupiter)", num_4: "Number 4 (Rahu)", num_5: "Number 5 (Mercury)", num_6: "Number 6 (Venus)", num_7: "Number 7 (Ketu)", num_8: "Number 8 (Saturn)", num_9: "Number 9 (Mars)",
        yogini_1: "Mangala", yogini_2: "Pingala", yogini_3: "Dhanya", yogini_4: "Bhramari", yogini_5: "Bhadrika", yogini_6: "Ulka", yogini_7: "Siddha", yogini_8: "Sankata",
        yogini_9: "Mangala", yogini_10: "Pingala", yogini_11: "Dhanya", yogini_12: "Bhramari", yogini_13: "Bhadrika", yogini_14: "Ulka", yogini_15: "Siddha", yogini_16: "Sankata",
        yogini_17: "Mangala", yogini_18: "Pingala", yogini_19: "Dhanya", yogini_20: "Bhramari", yogini_21: "Bhadrika", yogini_22: "Ulka", yogini_23: "Siddha", yogini_24: "Sankata",
        yogini_25: "Mangala", yogini_26: "Pingala", yogini_27: "Dhanya", yogini_28: "Bhramari", yogini_29: "Bhadrika", yogini_30: "Ulka", yogini_31: "Siddha", yogini_32: "Sankata",
        yogini_33: "Mangala", yogini_34: "Pingala", yogini_35: "Dhanya", yogini_36: "Bhramari", yogini_37: "Bhadrika", yogini_38: "Ulka", yogini_39: "Siddha", yogini_40: "Sankata",
        yogini_41: "Mangala", yogini_42: "Pingala", yogini_43: "Dhanya", yogini_44: "Bhramari", yogini_45: "Bhadrika", yogini_46: "Ulka", yogini_47: "Siddha", yogini_48: "Sankata",
        yogini_49: "Mangala", yogini_50: "Pingala", yogini_51: "Dhanya", yogini_52: "Bhramari", yogini_53: "Bhadrika", yogini_54: "Ulka", yogini_55: "Siddha", yogini_56: "Sankata",
        yogini_57: "Mangala", yogini_58: "Pingala", yogini_59: "Dhanya", yogini_60: "Bhramari", yogini_61: "Bhadrika", yogini_62: "Ulka", yogini_63: "Siddha", yogini_64: "Sankata",

        // ===== RUDRA, ADITYA, VASU, VASTU =====
        rudra_1: "Kapali", rudra_2: "Pingala", rudra_3: "Bhim", rudra_4: "Virupaksha", rudra_5: "Vilohita", rudra_6: "Ajapada", rudra_7: "Ahirbudhnya", rudra_8: "Shambhu", rudra_9: "Chand", rudra_10: "Bhava", rudra_11: "Ishana",
        aditya_1: "Dhata", aditya_2: "Mitra", aditya_3: "Aryaman", aditya_4: "Pushan", aditya_5: "Shakra", aditya_6: "Vivasvan", aditya_7: "Varuna", aditya_8: "Amsa", aditya_9: "Bhaga", aditya_10: "Tvashta", aditya_11: "Savita", aditya_12: "Vishnu",
        vasu_1: "Dhar", vasu_2: "Anala", vasu_3: "Ap", vasu_4: "Prithvi", vasu_5: "Anila", vasu_6: "Soma", vasu_7: "Aditya", vasu_8: "Pratyusha",
        vastu_north: "North Direction", vastu_south: "South Direction", vastu_east: "East Direction", vastu_west: "West Direction",
        vastu_entrance: "Main Entrance Vastu", vastu_kitchen: "Kitchen Vastu", vastu_bedroom: "Bedroom Vastu", vastu_pooja: "Pooja Room Vastu",
        rudraksha_1: "1 Mukhi Rudraksha", rudraksha_2: "2 Mukhi Rudraksha", rudraksha_3: "3 Mukhi Rudraksha", rudraksha_4: "4 Mukhi Rudraksha", rudraksha_5: "5 Mukhi Rudraksha", rudraksha_6: "6 Mukhi Rudraksha", rudraksha_7: "7 Mukhi Rudraksha", rudraksha_8: "8 Mukhi Rudraksha", rudraksha_9: "9 Mukhi Rudraksha", rudraksha_10: "10 Mukhi Rudraksha",
        gem_ruby: "Ruby (Manik)", gem_pearl: "Pearl (Moti)", gem_red_coral: "Red Coral (Moonga)", gem_emerald: "Emerald (Panna)", gem_yellow_sapphire: "Yellow Sapphire (Pukhraj)", gem_diamond: "Diamond (Heera)", gem_blue_sapphire: "Blue Sapphire (Neelam)", gem_hessonite: "Hessonite (Gomed)", gem_catseye: "Cat's Eye (Lehsunia)",
        vrat_monday: "Monday Fast", vrat_tuesday: "Tuesday Fast", vrat_thursday: "Thursday Fast", vrat_friday: "Friday Fast", vrat_saturday: "Saturday Fast", vrat_ekadashi: "Ekadashi Fast", vrat_pradosh: "Pradosh Vrat",
        sage_vashistha: "Vashistha", sage_vishwamitra: "Vishwamitra", sage_bharadwaj: "Bharadwaj", sage_atri: "Atri", sage_kashyapa: "Kashyapa", sage_gautama: "Gautama", sage_jamadagni: "Jamadagni",
        guna_1: "Varna", guna_2: "Vashya", guna_3: "Tara", guna_4: "Yoni", guna_5: "Graha Maitri", guna_6: "Gana", guna_7: "Bhakoot", guna_8: "Nadi",
        veda_rig: "Rigveda", veda_yajur: "Yajurveda", veda_sama: "Samaveda", veda_atharva: "Atharvaveda",
        upanishad_isha: "Isha Upanishad", upanishad_kena: "Kena Upanishad", upanishad_katha: "Katha Upanishad", upanishad_prashna: "Prashna Upanishad", upanishad_mundaka: "Mundaka Upanishad", upanishad_mandukya: "Mandukya Upanishad",

        back_home: "← Back to Home",

        months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],

edu_title: "Importance of Horoscope & Vedic Astrology",
edu_moon_h: "Influence of Moon Sign",
edu_moon_p: "In Vedic Astrology, horoscopes are always viewed based on the 'Moon Sign' because the Moon rules our mind and emotions.",
edu_guide_h: "Why Daily Guidance?",
edu_guide_p: "By understanding planetary transits, you can better plan your day and adopt 'Mahadev's Remedies' for upcoming obstacles.",
edu_finder_h: "Sign Finder (Magic Tool)",
edu_finder_p: "If you don't know your zodiac sign, use our 'Magic Finder' tool. it helps identify your correct sign based on your name or date of birth.",
faq_main_title: "Frequently Asked Questions (FAQ)",
faq_q1: "Is the horoscope 100% accurate?",
faq_a1: "No, daily horoscopes are general calculations based on transits. For 100% accuracy, a personal Birth Chart is essential.",
faq_q2: "What to do if the horoscope doesn't match?",
faq_a2: "If the results don't align, your 'Mahadasha' might be more dominant. In such cases, you should get a birth chart or palm analysis.",
faq_q3: "Which is better: Birth Chart or Palmistry?",
faq_a3: "A birth chart is best if birth time is known; otherwise, Palmistry becomes a reliable source of guidance by the grace of Mahadev.",
faq_footer_note: "* MAHADEV ASTROLOGER MA aims to alert you through astrological signs. We suggest taking this as guidance only.", 

"sound_page_title": "Naad Brahma: Divine Sound Science | MAHADEV ASTROLOGER MA",
"sound_hero_title": "Naad Brahma & Cosmic Resonance",
"sound_intro_para": "According to Vedic science, everything in the universe vibrates at a specific frequency. We link that 'Param-Naad' to your Kundali and Tridosha.",
about_rashi_title: "Ancient Vedic Wisdom",
naad_brahma_title: "Naad Brahma Resonance",
aries_desc: "Aries is the first sign of the zodiac, ruled by Mars (Mangal). As a Fire element, it represents energy, leadership, and the spark of creation.",
aries_resonance: "The spiritual frequency for Aries is linked to the Root Chakra. Chanting the Beej Mantra 'Ram' enhances mental strength and physical vitality.",
taurus_desc: "Taurus is an Earth sign ruled by Venus (Shukra). It represents stability, patience, and the material manifestation of nature.",
taurus_resonance: "The resonance of Taurus aligns with the Sacral Chakra. Chanting 'Eem' helps in attaining emotional balance and creative growth.",
gemini_desc: "Gemini is an Air sign ruled by Mercury (Budh). It symbolizes communication, intellect, and the dual nature of existence.",
gemini_resonance: "Gemini connects with the Throat Chakra. Chanting 'Aim' sharpens intelligence and brings clarity to expression.",
cancer_desc: "Cancer is a Water sign ruled by the Moon (Chandra). it represents intuition, care, and the depths of human emotions.",
cancer_resonance: "Cancer aligns with the Heart Chakra. Chanting 'Shreem' provides inner peace and strengthens emotional immunity.",
leo_desc: "Leo is a Fire sign ruled by the Sun (Surya). It symbolizes authority, vitality, and the radiant energy of the soul.",
leo_resonance: "Leo connects with the Solar Plexus. Chanting 'Hreem' invokes leadership qualities and spiritual confidence.",
virgo_desc: "Virgo is an Earth sign ruled by Mercury (Budh). It signifies precision, purity, and analytical wisdom.",
virgo_resonance: "Virgo vibrates with the Solar Plexus. Chanting 'Aim' brings meticulous focus and mental discipline.",
libra_desc: "Libra is an Air sign ruled by Venus (Shukra). It represents harmony, justice, and the balance of life's scales.",
libra_resonance: "Libra aligns with the Heart Chakra. Chanting 'Eem' fosters peace in relationships and inner harmony.",
scorpio_desc: "Scorpio is a Water sign ruled by Mars (Mangal). It symbolizes transformation, depth, and the power of occult wisdom.",
scorpio_resonance: "Scorpio resonates with the Sacral Chakra. Chanting 'Ram' helps in mastering willpower and spiritual transformation.",
sagittarius_desc: "Sagittarius is a Fire sign ruled by Jupiter (Guru). It represents truth, philosophy, and the higher spiritual journey.",
sagittarius_resonance: "Sagittarius connects with the Third Eye. Chanting 'Hreem' expands wisdom and brings focus to the life goal.",
capricorn_desc: "Capricorn is an Earth sign ruled by Saturn (Shani). It symbolizes discipline, perseverance, and worldly achievements.",
capricorn_resonance: "Capricorn aligns with the Root Chakra. Chanting 'Sham' provides stability and the strength to endure challenges.",
aquarius_desc: "Aquarius is an Air sign ruled by Saturn (Shani). It represents innovation, humanity, and universal consciousness.",
aquarius_resonance: "Aquarius resonates with the Third Eye. Chanting 'Sham' opens the mind to futuristic ideas and social harmony.",
pisces_desc: "Pisces is a Water sign ruled by Jupiter (Guru). It symbolizes the merger of the soul with the divine and spiritual liberation.",
pisces_resonance: "Pisces aligns with the Crown Chakra. Chanting 'Hreem' leads to deep meditation and spiritual enlightenment.",
"btn_start_quiz": "🔱 DISCOVER YOUR DOMINANT DOSHA",
"dosha_section_title": "Tridosha: Vibrational Balance",
"warning_label": "⚠️ CRITICAL:",
"dosha_warning_text": "This result is a primary estimate. Kundali analysis is mandatory for the correct healing frequency.",
"matrix_title": "Vedic Navgrah Resonance Matrix",
"col_planet": "Planet",
"col_raag": "Vedic Raag",
"col_status": "Status",
"ethics_title": "Ethical Boundary & Safety",
"ethics_desc": "Listening to random YouTube frequencies without Kundali analysis can be harmful. We provide only Shastra-based methods.",
"art_main_title": "Naad-Brahma: The Real DNA of Universe",
"art_para_1": "In Vedic science, music is part of 'Upaveda' (Gandharva Veda). We discuss the knowledge kept secret for centuries.",
"art_sub_1": "1. Mystery of 14 Frequencies from the Damru",
"art_para_2": "Panini explained how the sound of Mahadev's Damru gave birth to cosmic vibrations. Modern science calls this Cymatics.",
"art_sub_2": "2. YouTube Frequencies vs Authentic Vedic Sound",
"art_para_3": "Random frequencies can disturb your nervous system. Selection depends on your planetary degrees.",

"benefits_title": "Divine Benefits of Naad Healing",
"benefit_1": "Balances your mental state and reduces stress.",
"benefit_2": "Aligns your body vibrations with planetary energy.",  
"benefit_3": "Spiritual peace and vibrational balance through Vedic sounds.", 
    
 

// --- Quiz Result & Form ---
        "res_title": "Dominant Dosha:",
        "res_subtitle": "Select your preferred method to unlock your Frequency Chart:",
        "btn_kundali": "Via Kundali (Most Accurate)",
        "btn_palm": "Via Palmistry",
        "btn_num": "Via Numerology",
        "form_analysis": "Analysis",
        "form_mapping": "Mapping frequencies for your",
        "ph_name": "Full Name",
        "ph_whatsapp": "WhatsApp Number",
        "ph_place": "Birth Place (City/State)",
        "ph_issue": "Main Health/Life Concern? (Optional)",
        "btn_submit_form": "INVOKE FREQUENCY MAPPING ➔",
        "alert_success": "🔱 Request Sent! We will contact you on WhatsApp.",

// --- Hero & Intro ---
"sound_hero_quote": "Sound is the divine nectar of the future, provided its resonance is chosen according to your stars.",
"btn_read_article": "Explore Vedic Science ➔",

// --- Quiz Result (Missing Keys Added) ---
"res_status_label": "Current State:",
"res_path_label": "Alignment Path:",
"res_warning_title": "🔱 Mandatory Warning",
"res_warning_desc": "Without an exact analysis of <b>Planetary Positions</b>, using specific frequencies can harm your energy balance. These tips are intended to alert you about which resonance to avoid.",
"form_analysis_prompt": "For precise Frequency & Alignment, please provide details:",
"btn_consult_expert": "Consult with Expert ➔",
"new_art_footer_quote": "\"Mastering the Naad is mastering the Self; let the cosmic vibrations lead you to eternal balance.\"",

// --- VEDIC TOOLS DASHBOARD ---
    tools_main_title: "Vedic Tool Center",
    tools_main_sub: "Understand cosmic energies through mathematical formulas. Experience the wisdom of scriptures at your fingertips.",
    tool_kundli: "Birth chart",    
    tool_rashi: "Rashi Finder",
    tool_rashi_desc: "Identify your exact Moon Sign and element based on your first letter or date of birth.",
    btn_calc_now: "Calculate Now ➔",
    tool_tridosha: "Tridosha Test",
    tool_tridosha_desc: "Vata, Pitta, or Kapha? Understand your biological pulse and healing frequency.",
    btn_analyze: "Analyze Energy ➔",
    tool_grihdosh: "Grih Dosh Scanner",
    tool_grihdosh_desc: "Is your home energy balanced? Scientifically test for Vastu and subtle flaws.",
    btn_scan: "Scan Home ➔",
    tool_num: "Lucky Number",
    tool_num_desc: "Which cosmic number in your birth date will pave the way for your success?",
    btn_find_num: "Find Number ➔",
    tool_health: "Ayushman Bhava",
    tool_health_desc: "Know your daily water and step requirements based on your height and weight according to Ayurveda.",
    btn_check_health: "Check Health ➔",
    support_title: "Upcoming: Vedic Kundli Generator (D1 & D9)",
    support_desc: "We are developing an advanced digital chart engine. Do you want it for free on our website? Show your support!",
    btn_support: "🔱 SUPPORT THIS IDEA",

// --- GRIH DOSH SCANNER ---
    gd_title: "🔱 Grih Dosh Scanner",
    gd_desc: "Scientifically test your home's energy based on Vedic Vastu and Cosmic Energy.",
    gd_q1: "1. How do you feel immediately upon entering your home?",
    gd_q1_o1: "Peaceful and positive energy",
    gd_q1_o2: "Normal (nothing special)",
    gd_q1_o3: "Heaviness, suffocation, or unexplained anger",
    gd_q2: "2. What is the condition of the North-East corner of your home?",
    gd_q2_o1: "It is clean and has a worship space (Pooja room)",
    gd_q2_o2: "Heavy items or furniture are placed there",
    gd_q2_o3: "A toilet or garbage is located there",
    gd_q3: "3. What is the current status of wealth and health in your home?",
    gd_q3_o1: "Excellent health and financial growth",
    gd_q3_o2: "Money comes but is spent on illnesses",
    gd_q3_o3: "Continuous financial crisis and severe diseases",
    gd_q4: "4. Do electronic devices break down frequently without reason?",
    gd_q4_o1: "No, this doesn't happen",
    gd_q4_o2: "It happens sometimes",
    gd_q4_o3: "Yes, it happens very frequently",
    gd_btn_scan: "SCAN ENERGY ➔",
    gd_res_title: "Energy Report",
    gd_vastu_box_title: "✨ Why is Vastu Correction essential?",
    gd_vastu_box_p1: "When the directions and five elements of a house become imbalanced, it creates 'Geopathic Stress'. This stress directly blocks your financial growth and health.",
    gd_vastu_box_p2: "\"By simply aligning the energy and directions without any demolition, a house can be turned into a 'Positive Magnet'.\"",
    gd_btn_book: "Book Vastu Consultation ➔",
    
    // Dynamic JS Results
    gd_alert: "Please answer all questions for an accurate result.",
    gd_lvl_good: "🔱 Pure & Positive Energy",
    gd_rem_good: "Excellent! The energy of your home is extremely pure.<br><br><strong>Advice:</strong> Perform daily evening Aarti to maintain this positivity.",
    gd_lvl_mid: "⚠️ Moderate Energy Flaw",
    gd_rem_mid: "There is some Vastu Dosh or 'Geopathic Stress' present in your home.<br><br><strong>Advice:</strong> Keep the North-East corner clean and use sea salt for mopping. Read the article below for details.",
    gd_lvl_bad: "🛑 Severe Negative Flaw",
    gd_rem_bad: "According to the test, a heavy Vastu flaw is present, causing financial and physical harm.<br><br><strong>Urgent Advice:</strong> Play 'Mahamrityunjay Mantra' daily. Contact MAHADEV ASTROLOGER M.A. for personalized solutions.",

// --- GRIH DOSH ARTICLE ---
    gd_art_title: "Grih Dosh: Science, Cosmic Energy & Vedic Solutions",
    gd_art_quote: "\"Where energy is balanced, there resides Mahadev.\"",
    gd_art_p1: "Our home is not just a structure of bricks and stones; it is a living entity. The cosmic energy of the universe flows through our dwelling. When this energy is positive, happiness, peace, and prosperity reside in the house. But when the flow of this energy is obstructed, it is called 'Grih Dosh' in Vedic Astrology.",
    gd_art_p2: "In this research document by <strong>MAHADEV ASTROLOGER M.A.</strong>, we will understand that Grih Dosh is not merely an ancient belief, but holds deep science behind it.",
    gd_art_h1: "Scientific Perspective: Geopathic Stress",
    gd_art_p3: "What modern science calls 'Geopathic Stress' was identified by our ancient sages thousands of years ago as 'Vastu Dosh'. Magnetic and electric waves continuously flow within the earth's womb. When a house is constructed against these natural magnetic lines, a kind of stress is generated inside.",
    gd_art_li1_1: "<strong>Frequency Imbalance:</strong> The human body functions optimally at 7.83 Hz (Schumann Resonance). In a house with negative energy, this frequency gets disrupted, causing unexplained fatigue and anger.",
    gd_art_li1_2: "<strong>Impact on Electronics:</strong> Where negative ionic charge is high, electronic devices frequently malfunction.",
    gd_art_h2: "Main Symptoms of Negative Energy",
    gd_art_p4: "It is essential to understand Mahadev's signs. If you have Grih Dosh, you may experience:",
    gd_art_li2_1: "<strong>Health Loss:</strong> Continuous illness of family members and medicines having no effect.",
    gd_art_li2_2: "<strong>Financial Blockage:</strong> Stoppage of wealth inflow or inability to accumulate wealth.",
    gd_art_li2_3: "<strong>Mental Unrest:</strong> Feeling heaviness and suffocation immediately upon entering.",
    gd_art_li2_4: "<strong>Insomnia:</strong> Having bad dreams at night and incomplete sleep.",
    gd_art_highlight: "<strong>Shiva Sutra:</strong> From a place where there is constant discord, both Lakshmi and Narayan depart. Energy purification is the only way.",
    gd_art_h3: "Science of Directions and Shiva-Shakti Energy",
    gd_art_p5: "According to Vedic Vastu Shastra, each direction of the house controls a specific form of cosmic energy.",
    gd_art_li3_1: "<strong>North-East (Ishan):</strong> This is the water element and the place of Dev Guru Jupiter. Mahadev resides here. Impurity in this direction is the biggest Grih Dosh.",
    gd_art_li3_2: "<strong>South-East (Agneya):</strong> Place of the fire element. Imbalance here causes disease and wealth loss.",
    gd_art_li3_3: "<strong>South-West (Nairutya):</strong> The earth element. Flaws here cause instability and accidents in life.",
    gd_art_h4: "Infallible Vedic Solutions (Remedies)",
    gd_art_p6: "If you have found a flaw through our <strong>Grih Dosh Scanner</strong>, do not despair. By Mahadev's grace, there is a solution to every problem:",
    gd_art_sh1: "1. Use of Sound Energy (Healing)",
    gd_art_p7: "Acoustic waves of mantras are the most powerful method to destroy negative energy. Listen to 'Rudrashtakam' or 'Mahamrityunjay Mantra' at home during morning and evening. The sound of a conch shell (Shankh) and bell purifies the atmosphere.",
    gd_art_sh2: "2. Science of Sea Salt",
    gd_art_p8: "Sea salt has a wonderful ability to absorb negative ions. Always mix a little sea salt in the water while mopping the floor.",
    gd_art_sh3: "3. Fire of Camphor and Clove",
    gd_art_p9: "The chemical reaction that occurs when camphor burns purifies the air. Light camphor and cloves every evening and move it throughout the house.",
    gd_art_sh4: "4. Installation of Rudraksha",
    gd_art_p10: "Installing a five-faced (Panchmukhi) Rudraksha at the main door acts as an energy shield, preventing external negative energy from entering the house.",

    // --- AYUSHMAN BHAVA (HEALTH CALCULATOR) ---
    ab_title: "🔱 Ayushman Bhava",
    ab_desc: "Accurately measure your daily water and energy (steps) requirements according to Ayurveda and Sound Science.",
    ab_q1: "1. Your Height (in cm)",
    ab_q2: "2. Your Weight (in kg)",
    ab_btn: "CHECK MY HEALTH ➔",
    ab_res_title: "Your Daily Requirement",
    ab_lbl_water: "Water",
    ab_lbl_steps: "Steps",
    ab_lbl_bmi: "Body Index",
    ab_rem_title: "🌿 Vedic Daily Routine Sutras:",
    ab_rem_p1: "• <strong>Ushapan:</strong> Drink lukewarm water from a copper vessel immediately upon waking up without rinsing your mouth. It destroys all stomach ailments.",
    ab_rem_p2: "• <strong>How to Drink:</strong> Always drink water while sitting and sip by sip. Drinking water while standing causes knee and joint diseases.",
    ab_rem_p3: "• <strong>Food & Water:</strong> Drinking water immediately after meals is like poison. Consume water only an hour after your meal.",
    
    // Ayushman Bhava Article
    ab_art_title: "Ayurveda & Health: Cosmic Significance of Water and Walking",
    ab_art_quote: "\"A healthy body is the greatest wealth.\"",
    ab_art_p1: "Health is a person's greatest wealth. According to <strong>MAHADEV ASTROLOGER M.A.</strong>, our physical body is made of five elements (Fire, Water, Air, Earth, Space). Balancing the 'Water' element is crucial as our body is approximately 70% water. When water and air are imbalanced, the Tridoshas (Vata, Pitta, Kapha) arise.",
    ab_art_h1: "Accurate Water Intake Science",
    ab_art_p2: "Ayurveda clearly states that a person's water requirement depends on their weight. Generally, 33 ml of water is needed per 1 kg of weight. Proper water intake keeps your nadis (nerves) pure, making the effect of 'Naad Yoga' (Sound Healing) faster on the body.",
    ab_art_h2: "Daily Steps & Walking",
    ab_art_p3: "Both modern science and ancient Ayurveda confirm that regular walking is like nectar for the heart and digestive system. Walking during Brahma Muhurta provides pure oxygen to the brain, destroying mental stress and negative energy. Based on your Body Mass Index (BMI), you must walk 7,000 to 10,000 steps daily.",
        
        // --- NUMEROLOGY (LUCKY NUMBER) ---
    ln_title: "🔱 Advanced Numerology",
    ln_desc: "Know your Moolank, Bhagyank, Friendly/Enemy Numbers, and Cosmic Beej Mantra.",
    ln_q1: "1. Your Full Name",
    ln_q2: "2. Date of Birth",
    ln_btn: "GENERATE REPORT ➔",
    ln_res_title: "Cosmic Energy Report",
    ln_moolank: "Moolank",
    ln_bhagyank: "Bhagyank",
    ln_namank: "Namank",
    ln_lucky_lbl: "✅ Lucky Numbers",
    ln_avoid_lbl: "❌ Avoid Numbers",
    ln_lord_lbl: "🔱 Lord Planet: ",
    ln_color_lbl: "Lucky Color:",
    ln_day_lbl: "Lucky Day:",
    ln_mantra_lbl: "📿 Cosmic Beej Mantra:",
    
    // Numerology Article
    ln_art_title: "Numerology: Friendly, Enemy Numbers & Navgraha Mantras",
    ln_art_quote: "\"Every number represents a planet, and every planet is controlled by a mantra.\"",
    ln_art_p1: "Certain dates or mobile numbers prove to be very lucky for us, while some always cause harm. The reason is the cosmic science of Friendly and Enemy Numbers. According to <strong>MAHADEV ASTROLOGER M.A.</strong>, always choose your 'Lucky Numbers' when starting a new venture or buying a vehicle.",
    ln_art_h1: "Lords of Numbers 1 to 9 and Vedic Beej Mantras",
    ln_art_p2: "If your Moolank or Bhagyank is weak, chanting the Beej Mantra of your number's Lord Planet 108 times daily is the most infallible remedy. Here are the proven mantras:",
    ln_art_c1: "Number 1 (Sun)",
    ln_art_c2: "Number 2 (Moon)",
    ln_art_c3: "Number 3 (Jupiter)",
    ln_art_c4: "Number 4 (Rahu)",
    ln_art_c5: "Number 5 (Mercury)",
    ln_art_c6: "Number 6 (Venus)",
    ln_art_c7: "Number 7 (Ketu)",
    ln_art_c8: "Number 8 (Saturn)",
    ln_art_c9: "Number 9 (Mars)",
    ln_art_alert: "<strong>Special Consultation:</strong> Get your personalized Numerology Report from <strong>MAHADEV ASTROLOGER MA</strong> for Name Correction and detailed number analysis.",

   // Header & Meta
    "k_title": "Free Janam Kundli | MAHADEV ASTROLOGER MA",
    
    // Main Form Section
    "k_main_heading": "🔱 Janam Kundli (Kundli Engine)",
    "k_sub_heading": "Discover your Moon sign, Nakshatra, and Mangal Dosha based on precise cosmic calculations.",
    "k_dob_lbl": "1. Date of Birth",
    "k_time_lbl": "2. Time of Birth",
    "k_lat_lbl": "3. Latitude",
    "k_lon_lbl": "4. Longitude",
    "k_btn": "Generate Kundli ➔",
    
    // Result Section
    "k_res_title": "Cosmic Blueprint Result",
    
    // Article & SEO Section
    "k_art_title": "Importance of Vedic Kundli",
    "k_art_quote": "\"Planetary movements securely guide our cosmic journey.\"",
    "k_art_p1": "Human life is continuously influenced by cosmic energy and planetary movements. A Janam Kundli (Birth Chart) is a precise map of the celestial sphere at the exact time of an individual's birth. Through the advanced 'Astro Engine' of <strong>MAHADEV ASTROLOGER MA</strong>, you can obtain accurate calculations of your life's core elements.",
    "k_art_p2": "This cosmic blueprint provides a proper guide for your career, health, and marital life, helping you align your actions with the universe.",
    
    // FAQ Section
    "k_faq_h1": "Frequently Asked Questions",
    "k_faq_q1": "1. Is this Kundli calculation highly accurate?",
    "k_faq_a1": "Yes. <b>MAHADEV ASTROLOGER MA</b> utilizes an advanced API server that calculates planetary positions based on absolute astrological mathematics.",
    "k_faq_q2": "2. Does this tool detect Mangal Dosha?",
    "k_faq_a2": "Absolutely. Our system provides a clear indication of Mangal Dosha, helping you in marriage matchmaking and future planning.",
    
    // Alert Box
    "k_art_alert": "<strong>Special Consultation:</strong> Contact <strong>MAHADEV ASTROLOGER MA</strong> for a full horoscope analysis and precise remedies.",     

// ===== SOUND MODULE KEYS (EN) =====
status_locked: "🔐 LOCKED",
status_unlocked: "🔓 UNLOCKED",
raag_sun: "Deepak / Bilawal",
raag_moon: "Khamaj / Bhairavi",
raag_mars: "Bhairav / Marwa",
raag_mercury: "Sarang / Megh",
raag_jupiter: "Darbari / Todi",
raag_venus: "Yaman / Khamaj",
raag_saturn: "Bhimpalasi / Malkauns",
raag_rahu: "Chhayanat",
raag_ketu: "Lalit",

shop_title: "MAHADEV ASTROLOGER STORE",
        shop_subtitle: "100% Authentic Spiritual & Ayurvedic Products",
        fssai_reg: "✔ FSSAI REGISTERED",
        lab_cert: "✔ LAB CERTIFIED",
        vedic_energized: "✔ VEDIC ENERGIZED",
        divine_store: "Divine Store",
        cat_gemstones: "Gemstones",
        cat_rudraksha: "Rudraksha",
        cat_herbs: "Herbal Wellness",
        cat_energy_kits: "Energy Kits",
        how_to_order_title: "How to Order",
        step_01_label: "01. Select Category:",
        step_01_desc: "Choose from Gemstones, Rudraksha, or Herbs.",
        step_02_label: "02. WhatsApp Inquiry:",
        step_02_desc: "Click the 'Order' button to chat with us directly.",
        step_03_label: "03. Secure Payment:",
        step_03_desc: "Pay via UPI or Bank Transfer after selection.",
        step_04_label: "04. Fast Shipping:",
        step_04_desc: "Get your energized product delivered in 3-5 days.",  
},

   hi: {
        // ===== NAV & ZODIAC (HI) =====
        nav_home: "होम", nav_horoscope: "राशिफल", nav_panchang: "पंचांग", nav_guide: "अपडेट", nav_book: "बुक करें",nav_sound: "ध्वनि चिकित्सा",nav_tools: "वैदिक टूल्स",number_tool: "अंक ज्योतिष",nav_shop: "दुकान",
        zod_aries: "मेष", zod_taurus: "वृषभ", zod_gemini: "मिथुन", zod_cancer: "कर्क", zod_leo: "सिंह", zod_virgo: "कन्या", zod_libra: "तुला", zod_scorpio: "वृश्चिक", zod_sagittarius: "धनु", zod_capricorn: "मकर", zod_aquarius: "कुंभ", zod_pisces: "मीन",
        finder_title: "🔱 अपना राशि पहचानें (Rashi Finder)",
        finder_name_label: "नाम के पहले अक्षर से:", // HTML wali key se match karo
        finder_date_label: "जन्म तिथि और महीने से:",
        finder_select: "चुनें...",
        finder_divider: "या",
        'horoscope_title': 'दैनिक राशिफल',
        'horoscope_subtitle': 'अपनी राशि चुनें और आज का परामर्श प्राप्त करें',
        "guide_subtitle": "आधुनिक जीवन के लिए प्राचीन ज्ञान",
        "hero_mantra": "॥ नाद: स्वास्थ्यं च कालश्च, त्रयी शिवस्वरूपिणी ॥",
        "hero_tagline": "\"सुर, सेहत और सितारे — सब महादेव के सहारे\"",
        "hero_desc": "महादेव एस्ट्रोलॉजर MA में आपका स्वागत है। वैदिक ज्योतिष, आयुर्वेद और नाद उपचार के माध्यम से अपने भविष्य और ऊर्जा को सही दिशा दें।",

        player_title: "दिव्य संगीत 🔱", player_subtitle: "शीघ्र आ रहा है: पार्थ की आवाज़ में हीलिंग संगीत", player_msg: "प्रभु की कृपा से, दिव्य संगीत जल्द ही प्रकट होगा! 🚩",

       // Trust Building Section (User Benefits)
        "trust_title": "हम पर भरोसा क्यों करें?",
        "trust_pdf": "✨ <strong>फ्री PDF रिपोर्ट्स:</strong> बिना किसी अतिरिक्त शुल्क के अपनी विस्तृत परामर्श रिपोर्ट PDF में प्राप्त करें।",
        "trust_privacy": "🛡️ <strong>100% गोपनीयता:</strong> आपके व्यक्तिगत विवरण और डेटा को पूरी तरह सुरक्षित और गुप्त रखा जाता है।",
        "trust_connect": "💬 <strong>सीधा संपर्क:</strong> अपनी सुविधा के अनुसार WhatsApp, Telegram या Email के ज़रिए हमसे जुड़ें।",
        "trust_transparent": "📋 <strong>पारदर्शी प्रक्रिया:</strong> कोई छिपा हुआ शुल्क नहीं। हम पूरी पारदर्शिता में विश्वास रखते हैं।",

       // Unlock Divine Secrets Section
        "unlock_title": "दिव्य रहस्यों को जानें",
        "unlock_sub": "महादेव की रचनाओं का अनंत ज्ञान",
        "store_title": "अभिमंत्रित स्टोर (Astro Store)",
        "store_desc_en": "असली लैब-प्रमाणित रत्न, रुद्राक्ष और सरकारी मानकों (FSSAI) वाली जड़ी-बूटियाँ। सभी सामग्री/उत्पाद वैदिक रीति से अभिमंत्रित किये गए हैं।",
        "btn_explore_store": "स्टोर देखें ➔",
        "nav_vastu": "वास्तु शास्त्र परामर्श",
        "idx_vastu_desc_en": "16-जोन ऊर्जा विश्लेषण और बिना तोड़-फोड़ के आधुनिक वैदिक उपायों से अपने स्थान को मंगलमय बनाएं।",
        "btn_learn_more": "परामर्श बुक करें ➔",

       "ins_swapna_title": "वैदिक स्वप्न फल",
        "ins_swapna_desc": "स्वप्न शास्त्र के अनुसार अपने सपनों में छिपे रहस्यमयी ब्रह्मांडीय संकेतों और उनके उपायों को जानें।",
       "ins_mantra_title": "वैदिक मंत्र",
        "ins_mantra_desc": "शांति और ईश्वरीय कृपा के लिए सिद्ध मंत्रों का दैनिक पाठ करें।",
        "btn_read": "अभी पढ़ें",

        // Divine Bot
        "bot_welcome": "प्रणाम! मैं महादेव एस्ट्रोलॉजर MA का सहायक हूँ। क्या मैं आपको राशिफल दिखाऊँ या आपका कोई प्रश्न है?",
        "ph_bot_input": "अपना प्रश्न यहाँ लिखें...",

        ph_name_input: "आपका पूरा नाम", ph_wa_input: "व्हाट्सएप नंबर", ph_city_input: "जन्म स्थान / शहर",
        ph_m_name_input: "पुरुष का नाम", ph_f_name_input: "महिला का नाम", btn_submit: "दैवीय मार्गदर्शन प्राप्त करें", 
        rel_label: "किसके लिए जानकारी चाहिए?", rel_self: "स्वयं (मेरे लिए)", rel_father: "पिता जी", rel_mother: "माता जी", rel_spouse: "पति / पत्नी", rel_child: "बच्चा", rel_other: "अन्य / मित्र",

        site_title: "Mahadev Astrologer MA | दिव्य वैदिक ज्ञान",
        btn_install: "Mahadev Astrologer MA ऐप इंस्टॉल करें",
        hero_sub: "प्राचीन वैदिक परंपरा",
        hero_title: "अपने भाग्य का दिव्य सत्य जानें",
        hero_desc: "वैदिक ज्योतिष एवं शास्त्रोक्त सटीक उपाय, सीधे Mahadev Astrologer MA के माध्यम से।",
        "guide_title": "नवीनतम दिव्य मार्गदर्शन",

        event_tag: "होली 2026",
        event_text: "🔱 होली मुहूर्त और विधि",
        event_url: "https://www.mahadevastrologerma.in/latest-guide/article.html?id=7591463486673008592",

        svc_kundli_title: "कुण्डली निर्माण", svc_kundli_desc: "सटीक ग्रहों की स्थिति और व्यक्तिगत शास्त्रीय उपायों के साथ विस्तृत विश्लेषण।",
        svc_matching_title: "कुण्डली मिलान", svc_matching_desc: "वैवाहिक अनुकूलता, मंगल दोष की जांच और विशेषज्ञ गुण मिलान।",
        svc_combo_title: "कॉम्बो विश्लेषण", svc_combo_desc: "कुण्डली, हस्तरेखा और अंक ज्योतिष की संयुक्त PDF रिपोर्ट।",
        badge_best: "सर्वश्रेष्ठ", svc_palm_title: "हस्तरेखा विश्लेषण", svc_palm_desc: " सामुद्रिक शास्त्र के माध्यम से आपके करियर और छिपी क्षमताओं का अध्ययन।",
        svc_num_title: "अंक ज्योतिष", svc_num_desc: "अपना भाग्यशाली अंक, नाम सुधार और शुभ तिथियां जानें।",

        ins_horo_title: "आज का राशिफल", ins_horo_desc: "अपनी राशि के अनुसार जानें कैसा रहेगा आपका आज का दिन।",
        nav_articles: "दिव्य लेख संग्रह", articles_desc: "पौराणिक कथाएं और आध्यात्मिक ज्ञान का भंडार।",
        ins_panchang_desc: "आज की तिथि, नक्षत्र और शुभ मुहूर्त जानें",
        ins_panchang_title: "आज का पंचांग",


        btn_view: "विवरण देखें →", btn_read: "अभी पढ़ें →", btn_explore: "खोजें", btn_invoke: "परामर्श आरंभ करें", btn_send: "भेजें",
        form_title: "Mahadev Astrologer MA से परामर्श करें", lbl_select_service: "सेवा का चयन करें",
        opt_kundli: "कुंडली निर्माण (₹५०१)", opt_match: "कुंडली मिलान (₹६०१)", opt_palm: "हस्तरेखा विश्लेषण (₹५०१)", opt_num: "अंक ज्योतिष (₹२५१)", opt_combo: "♻️ कॉम्बो: कुंडली + हस्तरेखा (₹७०१)",
        
        lbl_privacy: "गोपनीयता एवं संपर्क प्राथमिकता:", lbl_uid: "क्लाइंट UID",
        lbl_male_details: "👦 पुरुष का विवरण", lbl_female_details: "👧 महिला का विवरण",
        palm_note: "✋ ध्यान दें:दोनों हाथ के दोनों तरफ के स्पष्ट चित्र तैयार रखें।",
        email_note: "⚠️ उत्तर देने में समय लग सकता है। व्हाट्सएप का उपयोग करें।",
        ph_name: "आपका पूर्ण नाम लिखें", ph_contact: "व्हाट्सएप / टेलीग्राम नंबर", ph_city: "जन्म स्थान (शहर)", ph_feedback: "अपना अनुभव साझा करें...",
        testi_title: "🔱 भक्त जनों के अनुभव", feedback_heading: "आपकी प्रतिक्रिया हमारे लिए महत्वपूर्ण है",

        // ===== PLANETS & HOUSES =====
        planet_sun: "सूर्य देव", planet_moon: "चंद्र देव", planet_mars: "मंगल देव", planet_mercury: "बुध देव", planet_jupiter: "बृहस्पति (गुरु)", planet_venus: "शुक्र देव", planet_saturn: "शनि देव", planet_rahu: "राहु ग्रह", planet_ketu: "केतु ग्रह",
        house_1: "प्रथम भाव (तनु)", house_2: "द्वितीय भाव (धन)", house_3: "तृतीय भाव (सहज)", house_4: "चतुर्थ भाव (सुख)", house_5: "पंचम भाव (सुत)", house_6: "षष्ठ भाव (रिपु)", house_7: "सप्तम भाव (जाया)", house_8: "अष्टम भाव (आयु)", house_9: "नवम भाव (भाग्य)", house_10: "दशम भाव (कर्म)", house_11: "एकादश भाव (आय)", house_12: "द्वादश भाव (व्यय)",

        // ===== NAKSHATRA & YOGA =====
        "nak_01": "अश्विनी", "nak_02": "भरणी", "nak_03": "कृत्तिका", "nak_04": "रोहिणी", "nak_05": "मृगशिरा",
        "nak_06": "आर्द्रा", "nak_07": "पुनर्वसु", "nak_08": "पुष्य", "nak_09": "आश्लेषा", "nak_10": "मघा",
        "nak_11": "पूर्वा फाल्गुनी", "nak_12": "उत्तरा फाल्गुनी", "nak_13": "हस्त", "nak_14": "चित्रा", "nak_15": "स्वाती",
        "nak_16": "विशाखा", "nak_17": "अनुराधा", "nak_18": "ज्येष्ठा", "nak_19": "मूल", "nak_20": "पूर्वाषाढ़ा",
        "nak_21": "उत्तराषाढ़ा", "nak_22": "श्रवण", "nak_23": "धनिष्ठा", "nak_24": "शतभिषा", "nak_25": "पूर्वा भाद्रपद",
        "nak_26": "उत्तर भाद्रपद", "nak_27": "रेवती",
        yoga_gajkesari: "गजकेसरी योग", yoga_budhaditya: "बुधादित्य योग", yoga_shasha: "शश योग", yoga_malavya: "मालव्य योग", yoga_hamsa: "हंस योग", yoga_bhadra: "भद्र योग", yoga_ruchaka: "रुचक योग", yoga_laxmi: "लक्ष्मी योग",
        dosha_mangal: "मंगल दोष", dosha_kaal_sarp: "काल सर्प दोष", dosha_pitar: "पितृ दोष",

        num_1: "नंबर 1 (सूर्य)", num_2: "नंबर 2 (चंद्र)", num_3: "नंबर 3 (गुरु)", num_4: "नंबर 4 (राहु)", num_5: "नंबर 5 (बुध)", num_6: "नंबर 6 (शुक्र)", num_7: "नंबर 7 (केतु)", num_8: "नंबर 8 (शनि)", num_9: "नंबर 9 (मंगल)",
        yogini_1: "मंगला", yogini_2: "पिंगला", yogini_3: "धन्या", yogini_4: "भ्रामरी", yogini_5: "भद्रिका", yogini_6: "उल्का", yogini_7: "सिद्धा", yogini_8: "संकटा",
        yogini_9: "मंगला", yogini_10: "पिंगला", yogini_11: "धन्या", yogini_12: "भ्रामरी", yogini_13: "भद्रिका", yogini_14: "उल्का", yogini_15: "सिद्धा", yogini_16: "संकटा",
        yogini_17: "मंगला", yogini_18: "पिंगला", yogini_19: "धन्या", yogini_20: "भ्रामरी", yogini_21: "Bhadrika", yogini_22: "Ulka", yogini_23: "Siddha", yogini_24: "Sankata",
        yogini_25: "Mangala", yogini_26: "Pingala", yogini_27: "Dhanya", yogini_28: "Bhramari", yogini_29: "Bhadrika", yogini_30: "Ulka", yogini_31: "Siddha", yogini_32: "Sankata",
        yogini_33: "Mangala", yogini_34: "Pingala", yogini_35: "Dhanya", yogini_36: "Bhramari", yogini_37: "Bhadrika", yogini_38: "Ulka", yogini_39: "Siddha", yogini_40: "Sankata",
        yogini_41: "Mangala", yogini_42: "Pingala", yogini_43: "Dhanya", yogini_44: "Bhramari", yogini_45: "Bhadrika", yogini_46: "Ulka", yogini_47: "Siddha", yogini_48: "Sankata",
        yogini_49: "Mangala", yogini_50: "Pingala", yogini_51: "Dhanya", yogini_52: "Bhramari", yogini_53: "Bhadrika", yogini_54: "Ulka", yogini_55: "Siddha", yogini_56: "Sankata",
        yogini_57: "मंगला", yogini_58: "पिंगला", yogini_59: "धन्या", yogini_60: "भ्रामरी", yogini_61: "भद्रिका", yogini_62: "उल्का", yogini_63: "सिद्धा", yogini_64: "संकटा",

        rudra_1: "कपाली", rudra_2: "पिंगल", rudra_3: "भीम", rudra_4: "विरूपाक्ष", rudra_5: "विलोहित", rudra_6: "अजपाद", rudra_7: "अहिर्बुध्न्य", rudra_8: "शम्भु", rudra_9: "चण्ड", rudra_10: "भव", rudra_11: "ईशान",
        aditya_1: "धाता", aditya_2: "मित्र", aditya_3: "अर्यमान", aditya_4: "पूषा", aditya_5: "शक्र", aditya_6: "विवस्वान", aditya_7: "वरुण", aditya_8: "अंश", aditya_9: "भग", aditya_10: "त्वष्टा", aditya_11: "सविता", aditya_12: "विष्णु",
        vasu_1: "धर", vasu_2: "अनल", vasu_3: "आप", vasu_4: "पृथ्वी", vasu_5: "अनिल", vasu_6: "सोम", vasu_7: "आदित्य", vasu_8: "प्रत्यूष",
        vastu_north: "उत्तर दिशा", vastu_south: "दक्षिण दिशा", vastu_east: "पूर्व दिशा", vastu_west: "पश्चिम दिशा",
        vastu_entrance: "मुख्य द्वार वास्तु", vastu_kitchen: "रसोईघर वास्तु", vastu_bedroom: "शयन कक्ष वास्तु", vastu_pooja: "पूजा कक्ष वास्तु",
        rudraksha_1: "एक मुखी रुद्राक्ष", rudraksha_2: "दो मुखी रुद्राक्ष", rudraksha_3: "तीन मुखी रुद्राक्ष", rudraksha_4: "चार मुखी रुद्राक्ष", rudraksha_5: "पांच मुखी रुद्राक्ष", rudraksha_6: "छह मुखी रुद्राक्ष", rudraksha_7: "सात मुखी रुद्राक्ष", rudraksha_8: "आठ मुखी रुद्राक्ष", rudraksha_9: "नौ मुखी रुद्राक्ष", rudraksha_10: "दस मुखी रुद्राक्ष",
        gem_ruby: "माणिक", gem_pearl: "मोती", gem_red_coral: "मूंगा", gem_emerald: "पन्ना", gem_yellow_sapphire: "पुखराज", gem_diamond: "हीरा", gem_blue_sapphire: "नीलम", gem_hessonite: "गोमेद", gem_catseye: "लहसुनिया",
        vrat_monday: "सोमवार व्रत", vrat_tuesday: "मंगलवार व्रत", vrat_thursday: "गुरुवार व्रत", vrat_friday: "शुक्रवार व्रत", vrat_saturday: "शनिवार व्रत", vrat_ekadashi: "एकादशी व्रत", vrat_pradosh: "प्रदोष व्रत",
        sage_vashistha: "वशिष्ठ", sage_vishwamitra: "विश्वामित्र", sage_bharadwaj: "भरद्वाज", sage_atri: "अत्रि", sage_kashyapa: "कश्यप", sage_gautama: "गौतम", sage_jamadagni: "जमदग्नि",
        guna_1: "वर्ण", guna_2: "वश्य", guna_3: "तारा", guna_4: "योनि", guna_5: "ग्रह मैत्री", guna_6: "गण", guna_7: "भकूट", guna_8: "नाड़ी",
        veda_rig: "ऋग्वेद", veda_yajur: "यजुर्वेद", veda_sama: "सामवेद", veda_atharva: "अथर्ववेद",
        upanishad_isha: "ईश उपनिषद", upanishad_kena: "केन उपनिषद", upanishad_katha: "कठ उपनिषद", upanishad_prashna: "प्रश्न उपनिषद", upanishad_mundaka: "मुण्डक उपनिषद", upanishad_mandukya: "माण्डूक्य उपनिषद",

    back_home: "← वापस जाएं",

        months: ["जनवरी", "फरवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"],

edu_title: "राशिफल और वैदिक ज्योतिष का महत्व",
edu_moon_h: "चंद्र राशि का प्रभाव",
edu_moon_p: "वैदिक ज्योतिष में राशिफल हमेशा 'चंद्र राशि' (Moon Sign) के आधार पर देखा जाता है, क्योंकि चंद्रमा हमारे मन और भावनाओं का स्वामी है।",
edu_guide_h: "दैनिक मार्गदर्शन क्यों?",
edu_guide_p: "ग्रहों के गोचर (Transit) को समझकर आप अपने दिन की योजना बेहतर बना सकते हैं और आने वाली बाधाओं के लिए 'महादेव के उपाय' अपना सकते हैं।",
edu_finder_h: "राशि पहचान (Finder Tool)",
edu_finder_p: "अगर आप अपनी राशि नहीं जानते, तो हमारे 'Magic Finder' टूल का उपयोग करें। यह आपके नाम या जन्म तिथि से सही राशि बताता है।",
faq_main_title: "महत्वपूर्ण प्रश्न और स्पष्टीकरण (FAQ)",
faq_q1: "क्या राशिफल 100% सटीक होता है?",
faq_a1: "नहीं, दैनिक राशिफल गोचर पर आधारित सामान्य गणना है। 100% सटीकता के लिए व्यक्तिगत जन्म कुंडली (Birth Chart) का होना अनिवार्य है।",
faq_q2: "अगर राशिफल मैच न हो तो क्या करें?",
faq_a2: "यदि परिणाम मेल नहीं खा रहे, तो आपकी कुंडली की 'महादशा' अधिक प्रभावी हो सकती है। ऐसी स्थिति में कुंडली या हस्तरेखा का विश्लेषण करवाना चाहिए।",
faq_q3: "कुंडली या हस्तरेखा: क्या बेहतर है?",
faq_a3: "जन्म समय ज्ञात होने पर कुंडली श्रेष्ठ है, अन्यथा हस्तरेखा (Palmistry) महादेव के आशीर्वाद से सटीक मार्गदर्शन का जरिया बनती है।",
faq_footer_note: "* MAHADEV ASTROLOGER MA का उद्देश्य आपको ज्योतिषीय संकेतों के माध्यम से सचेत करना है।", 

about_rashi_title: "प्राचीन वैदिक ज्ञान",
naad_brahma_title: "नाद ब्रह्म प्रतिध्वनि",
aries_desc: "मेष राशि चक्र की प्रथम राशि है, जिसका स्वामी मंगल है। अग्नि तत्व के रूप में, यह ऊर्जा, नेतृत्व और सृजन की शक्ति का प्रतीक है।",
aries_resonance: "मेष राशि की आध्यात्मिक आवृत्ति मूलाधार चक्र से जुड़ी है। बीज मंत्र 'रं' का जाप मानसिक शक्ति और शारीरिक जीवन शक्ति को बढ़ाता है।",
taurus_desc: "वृषभ एक पृथ्वी तत्व राशि है जिसका स्वामी शुक्र है। यह स्थिरता, धैर्य और प्रकृति की भौतिक अभिव्यक्ति का प्रतिनिधित्व करती है।",
taurus_resonance: "वृषभ की प्रतिध्वनि स्वाधिष्ठान चक्र के साथ संरेखित होती है। 'ईं' का जाप भावनात्मक संतुलन और रचनात्मक विकास में सहायता करता है।",
gemini_desc: "मिथुन एक वायु तत्व राशि है जिसका स्वामी बुध है। यह संचार, बुद्धि और अस्तित्व की द्वैत प्रकृति का प्रतीक है।",
gemini_resonance: "मिथुन विशुद्धि चक्र से जुड़ता है। 'ऐं' का जाप बुद्धि को तीव्र करता है और अभिव्यक्ति में स्पष्टता लाता है।",
cancer_desc: "कर्क एक जल तत्व राशि है जिसका स्वामी चंद्रमा है। यह अंतर्ज्ञान, संवेदनशीलता और मानवीय भावनाओं की गहराई को दर्शाता है।",
cancer_resonance: "कर्क अनाहत चक्र के साथ संरेखित होता है। 'श्रीं' का जाप आंतरिक शांति प्रदान करता है और भावनात्मक शक्ति को बढ़ाता है।",
leo_desc: "सिंह एक अग्नि तत्व राशि है जिसका स्वामी सूर्य है। यह अधिकार, जीवन शक्ति और आत्मा की तेजस्वी ऊर्जा का प्रतीक है।",
leo_resonance: "सिंह मणिपुर चक्र से जुड़ता है। 'ह्रीं' का जाप नेतृत्व के गुणों और आध्यात्मिक आत्मविश्वास का आह्वान करता है।",
virgo_desc: "कन्या एक पृथ्वी तत्व राशि है जिसका स्वामी बुध है। यह सटीकता, शुद्धता और विश्लेषणात्मक बुद्धिमत्ता का प्रतीक है।",
virgo_resonance: "कन्या मणिपुर चक्र के साथ कंपन करती है। 'ऐं' का जाप सूक्ष्म ध्यान और मानसिक अनुशासन लाता है।",
libra_desc: "तुला एक वायु तत्व राशि है जिसका स्वामी शुक्र है। यह सामंजस्य, न्याय और जीवन के संतुलन का प्रतिनिधित्व करती है।",
libra_resonance: "तुला अनाहत चक्र के साथ संरेखित होती है। 'ईं' का जाप संबंधों में शांति और आंतरिक सद्भाव को बढ़ावा देता है।",
scorpio_desc: "वृश्चिक एक जल तत्व राशि है जिसका स्वामी मंगल है। यह परिवर्तन, गहराई और आध्यात्मिक शक्ति का प्रतीक है।",
scorpio_resonance: "वृश्चिक स्वाधिष्ठान चक्र के साथ प्रतिध्वनित होता है। 'रं' का जाप इच्छाशक्ति और आध्यात्मिक रूपांतरण में सहायक है।",
sagittarius_desc: "धनु एक अग्नि तत्व राशि है जिसका स्वामी गुरु है। यह सत्य, दर्शन और उच्च आध्यात्मिक यात्रा का प्रतिनिधित्व करती है।",
sagittarius_resonance: "धनु आज्ञा चक्र से जुड़ता है। 'ह्रीं' का जाप ज्ञान का विस्तार करता है और जीवन के लक्ष्य पर ध्यान केंद्रित करता है।",
capricorn_desc: "मकर एक पृथ्वी तत्व राशि है जिसका स्वामी शनि है। यह अनुशासन, दृढ़ता और सांसारिक उपलब्धियों का प्रतीक है।",
capricorn_resonance: "मकर मूलाधार चक्र के साथ संरेखित होता है। 'शं' का जाप स्थिरता और चुनौतियों को सहने की शक्ति प्रदान करता है।",
aquarius_desc: "कुंभ एक वायु तत्व राशि है जिसका स्वामी शनि है। यह नवाचार, मानवता और सार्वभौमिक चेतना का प्रतिनिधित्व करती है।",
aquarius_resonance: "कुंभ आज्ञा चक्र के साथ प्रतिध्वनित होता है। 'शं' का जाप भविष्यवादी विचारों और सामाजिक सद्भाव के लिए मन को खोलता है।",
pisces_desc: "मीन एक जल तत्व राशि है जिसका स्वामी गुरु है। यह दिव्य चेतना के साथ आत्मा के विलय और आध्यात्मिक मुक्ति का प्रतीक है।",
pisces_resonance: "मीन सहस्रार चक्र के साथ संरेखित होता है। 'ह्रीं' का जाप गहन ध्यान और आध्यात्मिक ज्ञान की ओर ले जाता है।",

"btn_start_quiz": "🔱 अपने प्रमुख दोष की खोज करें",
"dosha_section_title": "त्रिदोष: कंपन संतुलन",
"warning_label": "⚠️ परम-आवश्यक:",
"dosha_warning_text": "यह परिणाम एक प्राथमिक अनुमान है। सही हीलिंग फ्रीक्वेंसी के लिए कुंडली विश्लेषण अनिवार्य है।",
"matrix_title": "वैदिक नवग्रह प्रतिध्वनि मैट्रिक्स",
"col_planet": "ग्रह",
"col_raag": "वैदिक राग",
"col_status": "स्थिति",
"ethics_title": "नैतिक सीमा और सुरक्षा",
"ethics_desc": "यूट्यूब की रैंडम फ्रीक्वेंसी बिना कुंडली विश्लेषण के सुनना हानिकारक हो सकता है। महादेव एस्ट्रोलॉजर एमए सिर्फ शास्त्रोक्त विधि ही प्रदान करता है।",
"art_main_title": "नाद-ब्रह्म: ब्रह्मांड का असली डीएनए",
"art_para_1": "वैदिक विज्ञान में संगीत 'उपवेद' (गंधर्व वेद) का हिस्सा है। हम उस ज्ञान की चर्चा कर रहे हैं जो सदियों से गुप्त रखा गया।",
"art_sub_1": "1. डमरू से निकली 14 आवृत्तियों का रहस्य",
"art_para_2": "पाणिनी ने बताया कि कैसे महादेव के डमरू की ध्वनि ने ब्रह्मांडीय कंपन को जन्म दिया। आधुनिक विज्ञान इसे साइमैटिक्स (Cymatics) कहता है।",
"art_sub_2": "2. यूट्यूब फ्रीक्वेंसी बनाम प्रामाणिक वैदिक ध्वनि",
"art_para_3": "यूट्यूब की रैंडम फ्रीक्वेंसी आपके तंत्रिका तंत्र (Nervous System) को परेशान कर सकती हैं।",

"benefits_title": "नाद उपचार के दिव्य लाभ",
"benefit_1": "यह आपकी मानसिक स्थिति को संतुलित करता है और तनाव कम करता है।",
"benefit_2": "यह आपके शरीर के स्पंदन को ग्रहों की ऊर्जा के साथ जोड़ता है।",
"benefit_3": "वैदिक ध्वनियों के माध्यम से आत्मिक शांति और संतुलन।",
        


// --- Quiz Result & Form ---
        "res_title": "प्रमुख दोष:",
        "res_subtitle": "अपना फ्रीक्वेंसी चार्ट प्राप्त करने के लिए अपनी पसंदीदा विधि चुनें:",
        "btn_kundali": "कुण्डली द्वारा (सबसे सटीक)",
        "btn_palm": "हस्तरेखा द्वारा",
        "btn_num": "अंक ज्योतिष द्वारा",
        "form_analysis": "विश्लेषण",
        "form_mapping": "आपके प्रोफाइल के लिए फ्रीक्वेंसी मैपिंग:",
        "ph_name": "पूरा नाम",
        "ph_whatsapp": "व्हाट्सएप नंबर",
        "ph_place": "जन्म स्थान (शहर/राज्य)",
        "ph_issue": "आपकी मुख्य समस्या? (वैकल्पिक)",
        "btn_submit_form": "फ्रीक्वेंसी मैपिंग शुरू करें ➔",
        "alert_success": "🔱 अनुरोध भेज दिया गया है! हम आपसे व्हाट्सएप पर संपर्क करेंगे।",

// --- Hero & Intro (Urdu Removed) ---
"sound_hero_quote": "नाद (ध्वनि) भविष्य का दिव्य अमृत है, यदि उसका चयन आपके नक्षत्रों के अनुरूप हो।",
"btn_read_article": "वैदिक विज्ञान को समझें ➔",

// --- Quiz Result (Missing Keys Added) ---
"res_status_label": "वर्तमान स्थिति:",
"res_path_label": "अलाइनमेंट मार्ग:",
"res_warning_title": "🔱 अनिवार्य चेतावनी / Disclaimer",
"res_warning_desc": "बिना सटीक <b>Planetary Positions (ग्रहों की स्थिति)</b> के विश्लेषण के, किसी भी फ्रीक्वेंसी का प्रयोग ऊर्जा चक्रों को असंतुलित कर सकता है। यह जानकारी आपको केवल सतर्क करने के लिए है।",
"form_analysis_prompt": "सटीक फ्रीक्वेंसी और सुरक्षित अलाइनमेंट के लिए विवरण भरें:",
"btn_consult_expert": "विशेषज्ञ परामर्श प्राप्त करें ➔",
"new_art_footer_quote": "“नाद की सिद्धि ही स्वयं की सिद्धि है; ब्रह्मांडीय स्पंदनों को अपने जीवन के परम संतुलन का मार्ग बनने दें।”",

// --- VEDIC TOOLS DASHBOARD ---
    tools_main_title: "वैदिक टूल सेंटर",
    tools_main_sub: "ब्रह्मांडीय ऊर्जाओं को गणितीय सूत्रों से समझने का दिव्य प्रयास। शास्त्रों के ज्ञान को अपनी उंगलियों पर अनुभव करें।",
    tool_kundli: "जन्म कुंडली",     
    tool_rashi: "राशि पहचानें",
    tool_rashi_desc: "नाम के प्रथम अक्षर या जन्म तिथि के आधार पर अपनी सटीक चंद्र राशि (Moon Sign) और तत्व पहचानें।",
    btn_calc_now: "अभी गणना करें ➔",
    tool_tridosha: "त्रिदोष परीक्षण",
    tool_tridosha_desc: "वात, पित्त या कफ? अपने शरीर की जैविक प्रकृति और हीलिंग फ्रीक्वेंसी का ज्ञान प्राप्त करें।",
    btn_analyze: "ऊर्जा विश्लेषण ➔",
    tool_grihdosh: "गृह दोष स्कैनर",
    tool_grihdosh_desc: "क्या आपके घर की ऊर्जा संतुलित है? वास्तु और सूक्ष्म दोषों का वैज्ञानिक परीक्षण करें और शिव-उपाय पाएं।",
    btn_scan: "परीक्षण करें ➔",
    tool_num: "अंक ज्योतिष",
    tool_num_desc: "आपकी जन्म तिथि में कौन सा शक्तिशाली अंक (Cosmic Number) आपकी सफलता का मार्ग प्रशस्त करेगा?",
    btn_find_num: "अंक जानें ➔",
    tool_health: "आयुष्मान भव:",
    tool_health_desc: "आयुर्वेद के अनुसार अपने शारीरिक भार और ऊंचाई से दैनिक जल (Water) और पद-यात्रा (Steps) की सटीक आवश्यकता जानें।",
    btn_check_health: "स्वास्थ्य जाँच ➔",
    support_title: "आगामी: वैदिक कुंडली जनरेटर (D1 & D9)",
    support_desc: "हम एक उन्नत डिजिटल चार्ट इंजन (Kundali Engine) तैयार कर रहे हैं। क्या आप इसे हमारी वेबसाइट पर निःशुल्क चाहते हैं? अपना समर्थन दर्ज करें!",
    btn_support: "🔱 समर्थन करें",

// --- GRIH DOSH SCANNER ---
    gd_title: "🔱 गृह दोष स्कैनर",
    gd_desc: "वैदिक वास्तु और ब्रह्मांडीय ऊर्जा (Cosmic Energy) के आधार पर अपने घर का वैज्ञानिक परीक्षण करें।",
    gd_q1: "1. घर में प्रवेश करते ही आपको कैसा अनुभव होता है?",
    gd_q1_o1: "शांति और सकारात्मक ऊर्जा",
    gd_q1_o2: "सामान्य (कुछ विशेष नहीं)",
    gd_q1_o3: "भारीपन, घुटन या अकारण क्रोध",
    gd_q2: "2. घर के ईशान कोण (North-East) की स्थिति क्या है?",
    gd_q2_o1: "स्वच्छ है और वहां पूजा स्थान है",
    gd_q2_o2: "वहां भारी सामान रखा है",
    gd_q2_o3: "वहां शौचालय (Toilet) या कूड़ा है",
    gd_q3: "3. धन और स्वास्थ्य की वर्तमान स्थिति कैसी है?",
    gd_q3_o1: "उत्तम स्वास्थ्य और आर्थिक वृद्धि",
    gd_q3_o2: "धन आता है परंतु रोग में व्यय होता है",
    gd_q3_o3: "निरंतर आर्थिक संकट और गंभीर रोग",
    gd_q4: "4. क्या घर में इलेक्ट्रॉनिक उपकरण अकारण खराब होते हैं?",
    gd_q4_o1: "नहीं, ऐसा नहीं होता",
    gd_q4_o2: "कभी-कभी होता है",
    gd_q4_o3: "हाँ, बहुत अधिक होता है",
    gd_btn_scan: "SCAN ENERGY ➔",
    gd_res_title: "Energy Report",
    gd_vastu_box_title: "✨ Vastu Correction (वास्तु उपाय) क्यों ज़रूरी है?",
    gd_vastu_box_p1: "जब घर की दिशाएं और पंचतत्व (Earth, Water, Fire, Air, Space) असंतुलित हो जाते हैं, तो इसे <strong>'Geopathic Stress'</strong> कहा जाता है। यह तनाव सीधे आपकी आर्थिक वृद्धि और स्वास्थ्य को अवरुद्ध करता है।",
    gd_vastu_box_p2: "\"बिना तोड़-फोड़ के केवल ऊर्जा (Energy) और दिशाओं को अलाइन करके घर को एक 'सकारात्मक चुंबक' (Positive Magnet) बनाया जा सकता है।\"",
    gd_btn_book: "Book Vastu Consultation ➔",
    
    // Dynamic JS Results
    gd_alert: "सटीक परिणाम हेतु कृपया सभी प्रश्नों के उत्तर दें।",
    gd_lvl_good: "🔱 शुद्ध एवं सकारात्मक ऊर्जा",
    gd_rem_good: "अति उत्तम! आपके घर की ऊर्जा अत्यंत शुद्ध है।<br><br><strong>परामर्श:</strong> इस सकारात्मकता को बनाए रखने के लिए नित्य संध्या आरती करें।",
    gd_lvl_mid: "⚠️ मध्यम ऊर्जा दोष",
    gd_rem_mid: "आपके घर में कुछ वास्तु दोष या 'Geopathic Stress' उपस्थित है।<br><br><strong>परामर्श:</strong> ईशान कोण (North-East) को स्वच्छ रखें और समुद्री नमक का प्रयोग करें। विस्तृत जानकारी नीचे दिए गए लेख में पढ़ें।",
    gd_lvl_bad: "🛑 तीव्र नकारात्मक दोष",
    gd_rem_bad: "परीक्षण के अनुसार घर में भारी वास्तु दोष उपस्थित है, जो आर्थिक एवं शारीरिक हानि का कारण है।<br><br><strong>तत्काल परामर्श:</strong> घर में नित्य 'महामृत्युंजय मंत्र' चलाएं। व्यक्तिगत समाधान हेतु <strong>MAHADEV ASTROLOGER M.A.</strong> से संपर्क करें।",

// --- GRIH DOSH ARTICLE ---
    gd_art_title: "गृह दोष: विज्ञान, ब्रह्मांडीय ऊर्जा और वैदिक समाधान",
    gd_art_quote: "\"जहाँ ऊर्जा का संतुलन है, वहीं महादेव का वास है।\"",
    gd_art_p1: "हमारा घर केवल ईंट और पत्थर का ढांचा नहीं है; यह एक जीवंत इकाई (Living Entity) है। ब्रह्मांड की समस्त ऊर्जा हमारे निवास स्थान से होकर गुजरती है। जब यह ऊर्जा सकारात्मक होती है, तो घर में सुख, शांति और समृद्धि का वास होता है। परंतु जब इस ऊर्जा का प्रवाह बाधित होता है, तो उसे वैदिक ज्योतिष में <strong>'गृह दोष' (Grih Dosh)</strong> कहा जाता है।",
    gd_art_p2: "<strong>MAHADEV ASTROLOGER M.A.</strong> के इस शोध पत्र में हम यह समझेंगे कि गृह दोष केवल एक प्राचीन मान्यता नहीं है, बल्कि इसके पीछे गहरा विज्ञान (Science) छिपा है।",
    gd_art_h1: "वैज्ञानिक दृष्टिकोण: जियोपैथिक स्ट्रेस (Geopathic Stress)",
    gd_art_p3: "आधुनिक विज्ञान जिसे 'Geopathic Stress' कहता है, हमारे प्राचीन ऋषियों ने उसे सहस्रों वर्ष पूर्व 'वास्तु दोष' के रूप में पहचान लिया था। पृथ्वी के गर्भ में निरंतर चुंबकीय (Magnetic) और विद्युतीय (Electric) तरंगें बहती रहती हैं। जब घर का निर्माण पृथ्वी की इन प्राकृतिक चुंबकीय रेखाओं के विरुद्ध किया जाता है, तो घर के भीतर एक प्रकार का तनाव उत्पन्न होता है।",
    gd_art_li1_1: "<strong>फ्रीक्वेंसी का असंतुलन:</strong> मानव शरीर 7.83 Hz (Schumann Resonance) पर सर्वोत्तम कार्य करता है। नकारात्मक ऊर्जा वाले घर में यह फ्रीक्वेंसी बिगड़ जाती है, जिससे अकारण थकान और क्रोध उत्पन्न होता है।",
    gd_art_li1_2: "<strong>इलेक्ट्रॉनिक्स पर प्रभाव:</strong> जहाँ नकारात्मक ऊर्जा (Negative Ionic Charge) अधिक होती है, वहाँ इलेक्ट्रॉनिक उपकरण बार-बार खराब होते हैं।",
    gd_art_h2: "घर में नकारात्मक ऊर्जा के मुख्य लक्षण",
    gd_art_p4: "महादेव के संकेतों को समझना आवश्यक है। यदि आपके घर में गृह दोष है, तो आपको निम्नलिखित लक्षण अनुभव हो सकते हैं:",
    gd_art_li2_1: "<strong>स्वास्थ्य हानि:</strong> घर के सदस्यों का निरंतर अस्वस्थ रहना और औषधियों का प्रभाव न होना।",
    gd_art_li2_2: "<strong>आर्थिक अवरोध:</strong> धन का आगमन रुक जाना या धन संचय न हो पाना।",
    gd_art_li2_3: "<strong>मानसिक अशांति:</strong> घर में प्रवेश करते ही भारीपन और घुटन का अनुभव होना।",
    gd_art_li2_4: "<strong>अनिद्रा (Insomnia):</strong> रात्रि में बुरे स्वप्न आना और नींद पूर्ण न होना।",
    gd_art_highlight: "<strong>शिव सूत्र:</strong> जिस स्थान पर निरंतर कलह होता है, वहाँ से लक्ष्मी और नारायण दोनों प्रस्थान कर जाते हैं। ऊर्जा का शुद्धिकरण ही एकमात्र मार्ग है।",
    gd_art_h3: "दिशाओं का विज्ञान और शिव-शक्ति ऊर्जा",
    gd_art_p5: "वैदिक वास्तु शास्त्र के अनुसार, घर की प्रत्येक दिशा ब्रह्मांडीय ऊर्जा के एक विशिष्ट रूप को नियंत्रित करती है।",
    gd_art_li3_1: "<strong>ईशान कोण (North-East):</strong> यह जल तत्व और देव गुरु बृहस्पति का स्थान है। यहाँ महादेव का वास माना जाता है। इस दिशा का अशुद्ध होना सबसे बड़ा गृह दोष है।",
    gd_art_li3_2: "<strong>आग्नेय कोण (South-East):</strong> यह अग्नि तत्व का स्थान है। यहाँ असंतुलन होने पर घर में रोग और धन हानि होती है।",
    gd_art_li3_3: "<strong>नैऋत्य कोण (South-West):</strong> यह पृथ्वी तत्व है। यहाँ का दोष जीवन में अस्थिरता और दुर्घटनाओं का कारण बनता है।",
    gd_art_h4: "अचूक वैदिक समाधान (Vedic Remedies)",
    gd_art_p6: "यदि आपने हमारे <strong>Grih Dosh Scanner</strong> के माध्यम से घर में दोष पाया है, तो निराश न हों। महादेव की कृपा से हर समस्या का समाधान उपलब्ध है:",
    gd_art_sh1: "1. ध्वनि ऊर्जा (Sound Healing) का प्रयोग",
    gd_art_p7: "मंत्रों की ध्वनि तरंगें (Acoustic Waves) नकारात्मक ऊर्जा को नष्ट करने की सबसे शक्तिशाली विधि हैं। प्रातः और संध्या के समय घर में 'रुद्राष्टकम' या 'महामृत्युंजय मंत्र' का श्रवण करें। शंख और घंटी की ध्वनि घर के वायुमंडल को शुद्ध करती है।",
    gd_art_sh2: "2. समुद्री नमक (Sea Salt) का विज्ञान",
    gd_art_p8: "समुद्री नमक में नकारात्मक आयनों (Negative Ions) को सोखने की अद्भुत क्षमता होती है। घर में पोंछा लगाते समय जल में थोड़ा सा समुद्री नमक अवश्य मिलाएं।",
    gd_art_sh3: "3. कर्पूर और लौंग की अग्नि",
    gd_art_p9: "कर्पूर (Camphor) जलने पर जो रासायनिक प्रतिक्रिया (Chemical Reaction) होती है, वह वायु को शुद्ध करती है। नित्य संध्याकाल में कर्पूर और लौंग प्रज्वलित कर पूरे घर में घुमाएं।",
    gd_art_sh4: "4. रुद्राक्ष की स्थापना",
    gd_art_p10: "पंचमुखी रुद्राक्ष को घर के मुख्य द्वार पर स्थापित करने से यह एक सुरक्षा कवच (Energy Shield) का कार्य करता है, जो बाहरी नकारात्मक ऊर्जा को घर में प्रवेश करने से रोकता है।",

    // --- NUMEROLOGY (LUCKY NUMBER) ---
    ln_title: "🔱 अंक ज्योतिष कैलकुलेटर",
    ln_desc: "अपना मूलांक, भाग्यांक, शुभ/अशुभ अंक (Friendly & Enemy Numbers) और बीज मंत्र जानें।",
    ln_q1: "1. आपका पूरा नाम (Full Name)",
    ln_q2: "2. जन्म तिथि (Date of Birth)",
    ln_btn: "अंक जानें ➔",
    ln_res_title: "ब्रह्मांडीय ऊर्जा रिपोर्ट",
    ln_moolank: "मूलांक",
    ln_bhagyank: "भाग्यांक",
    ln_namank: "नामांक",
    ln_lucky_lbl: "✅ शुभ अंक (Lucky Numbers)",
    ln_avoid_lbl: "❌ शत्रु अंक (Avoid Numbers)",
    ln_lord_lbl: "🔱 स्वामी ग्रह: ",
    ln_color_lbl: "शुभ रंग:",
    ln_day_lbl: "शुभ दिन:",
    ln_mantra_lbl: "📿 सिद्ध बीज मंत्र:",
    
    // Numerology Article
    ln_art_title: "अंक ज्योतिष: मित्र, शत्रु अंक और नवग्रह मंत्र",
    ln_art_quote: "\"प्रत्येक अंक एक ग्रह का प्रतिनिधित्व करता है, और प्रत्येक ग्रह एक मंत्र से नियंत्रित होता है।\"",
    ln_art_p1: "हमारे जीवन में कुछ तारीखें या मोबाइल नंबर हमारे लिए बहुत भाग्यशाली (Lucky) साबित होते हैं, जबकि कुछ नंबर हमें हमेशा नुकसान पहुँचाते हैं। इसका कारण है मित्र और शत्रु अंकों का ब्रह्मांडीय विज्ञान। <strong>MAHADEV ASTROLOGER M.A.</strong> के अनुसार, यदि आप कोई नया कार्य आरंभ कर रहे हैं, तो हमेशा अपने 'शुभ अंकों' का ही चयन करें।",
    ln_art_h1: "1 से 9 अंकों के स्वामी ग्रह और उनके वैदिक बीज मंत्र",
    ln_art_p2: "यदि आपका मूलांक या भाग्यांक कमज़ोर है, तो अपने अंक के स्वामी ग्रह (Lord Planet) के <strong>बीज मंत्र</strong> का नित्य 108 बार जाप करना सबसे अचूक उपाय है। यहाँ 1 से 9 अंकों के स्वामी और उनके सिद्ध मंत्र दिए गए हैं:",
    ln_art_c1: "अंक 1 (सूर्य)",
    ln_art_c2: "अंक 2 (चंद्रमा)",
    ln_art_c3: "अंक 3 (गुरु)",
    ln_art_c4: "अंक 4 (राहु)",
    ln_art_c5: "अंक 5 (बुध)",
    ln_art_c6: "अंक 6 (शुक्र)",
    ln_art_c7: "अंक 7 (केतु)",
    ln_art_c8: "अंक 8 (शनि)",
    ln_art_c9: "अंक 9 (मंगल)",
    ln_art_alert: "<strong>विशेष परामर्श:</strong> नाम की स्पेलिंग (Name Correction) और अंकों के महा-विश्लेषण के लिए <strong>MAHADEV ASTROLOGER MA</strong> से अपनी व्यक्तिगत न्यूमरोलॉजी रिपोर्ट प्राप्त करें।",    

    // Header & Meta
    "k_title": "फ्री जन्म कुण्डली | MAHADEV ASTROLOGER MA",
    
    // Main Form Section
    "k_main_heading": "🔱 जन्म कुण्डली (Kundli Engine)",
    "k_sub_heading": "सटीक ब्रह्मांडीय गणनाओं के आधार पर अपना राशिफल, नक्षत्र और मंगल दोष जानें।",
    "k_dob_lbl": "1. जन्म तिथि (Date of Birth)",
    "k_time_lbl": "2. जन्म समय (Time of Birth)",
    "k_lat_lbl": "3. अक्षांश (Latitude)",
    "k_lon_lbl": "4. देशांतर (Longitude)",
    "k_btn": "कुण्डली बनाएं ➔",
    
    // Result Section
    "k_res_title": "ब्रह्मांडीय ऊर्जा परिणाम",
    
    // Article & SEO Section
    "k_art_title": "वैदिक कुण्डली का महत्व",
    "k_art_quote": "\"ग्रहों की गति हमारे जीवन का मार्गदर्शन करती है।\"",
    "k_art_p1": "मानव जीवन ब्रह्मांडीय ऊर्जा (Cosmic Energy) और ग्रहों की गति से निरंतर प्रभावित होता है। जन्म कुण्डली व्यक्ति के जन्म के समय आकाश मंडल का एक सटीक नक्शा है। <strong>MAHADEV ASTROLOGER MA</strong> के इस उन्नत 'Astro Engine' के माध्यम से आप अपने जीवन के मूल तत्वों की सटीक गणना प्राप्त कर सकते हैं।",
    "k_art_p2": "यह ब्रह्मांडीय ब्लूप्रिंट आपके करियर, स्वास्थ्य और दांपत्य जीवन के लिए उचित मार्गदर्शिका प्रदान करता है, जिससे आप अपने कर्मों को ब्रह्मांड के अनुकूल बना सकते हैं।",
    
    // FAQ Section
    "k_faq_h1": "सामान्य प्रश्न (FAQ)",
    "k_faq_q1": "1. क्या यह कुण्डली गणना पूर्णतः सटीक है?",
    "k_faq_a1": "हाँ। <b>MAHADEV ASTROLOGER MA</b> एक उन्नत API सर्वर का उपयोग करता है जो पूर्ण ज्योतिषीय गणित के आधार पर ग्रहों की स्थिति की गणना करता है।",
    "k_faq_q2": "2. क्या यह उपकरण मंगल दोष का संकेत देता है?",
    "k_faq_a2": "अवश्य। हमारा सिस्टम मंगल दोष का स्पष्ट संकेत प्रदान करता है, जो विवाह मिलान और भविष्य की योजना में आपकी सहायता करता है।",
    
    // Alert Box
    "k_art_alert": "<strong>विशेष परामर्श:</strong> संपूर्ण कुण्डली विश्लेषण और सटीक उपाय जानने के लिए <strong>MAHADEV ASTROLOGER MA</strong> से संपर्क करें।",
        
    // --- AYUSHMAN BHAVA (HEALTH CALCULATOR) ---
    ab_title: "🔱 आयुष्मान भव:",
    ab_desc: "आयुर्वेद और नाद विज्ञान के अनुसार अपनी शारीरिक प्रकृति, दैनिक जल (Water) और ऊर्जा (Steps) का सटीक मापन करें।",
    ab_q1: "1. आपकी ऊंचाई / Height (cm में)",
    ab_q2: "2. आपका भार / Weight (kg में)",
    ab_btn: "स्वास्थ्य जाँच ➔",
    ab_res_title: "आपकी दैनिक आवश्यकता",
    ab_lbl_water: "जल (Water)",
    ab_lbl_steps: "पद-यात्रा",
    ab_lbl_bmi: "शारीरिक सूचकांक",
    ab_rem_title: "🌿 वैदिक दिनचर्या सूत्र:",
    ab_rem_p1: "• <strong>उषापान:</strong> प्रातःकाल उठते ही बिना कुल्ला किए तांबे के पात्र का गुनगुना जल ग्रहण करें। यह उदर (पेट) के सभी रोगों का नाश करता है।",
    ab_rem_p2: "• <strong>जल ग्रहण विधि:</strong> जल सदैव बैठकर और घूंट-घूंट (Sip by Sip) पिएं। खड़े होकर जल पीने से घुटनों और जोड़ों के रोग उत्पन्न होते हैं।",
    ab_rem_p3: "• <strong>भोजन और जल:</strong> भोजन के तुरंत पश्चात जल ग्रहण करना विष (Poison) के समान है। भोजन के एक घंटे पश्चात ही जल ग्रहण करें।",
    
    // Ayushman Bhava Article
    ab_art_title: "आयुर्वेद और स्वास्थ्य: जल एवं पद-यात्रा का ब्रह्मांडीय महत्व",
    ab_art_quote: "\"पहला सुख निरोगी काया।\"",
    ab_art_p1: "स्वास्थ्य ही मनुष्य का सबसे बड़ा धन है। <strong>MAHADEV ASTROLOGER M.A.</strong> के अनुसार, हमारा भौतिक शरीर पंच तत्वों (अग्नि, जल, वायु, पृथ्वी, आकाश) से निर्मित है। इन सभी में 'जल' तत्व का संतुलन अत्यंत आवश्यक है क्योंकि हमारे शरीर का लगभग 70 प्रतिशत भाग जल ही है। जब हमारे शरीर में जल और वायु का संतुलन बिगड़ता है, तब त्रिदोष (वात, पित्त, कफ) उत्पन्न होते हैं।",
    ab_art_h1: "सटीक जल पान (Water Intake Science)",
    ab_art_p2: "आयुर्वेद का स्पष्ट निर्देश है कि प्रत्येक व्यक्ति की जल की आवश्यकता उसके भार (Weight) पर निर्भर करती है। सामान्य रूप से, प्रत्येक 1 किलोग्राम भार के लिए 33 मिली-लीटर जल की आवश्यकता होती है। यदि आप उचित मात्रा में जल ग्रहण करते हैं, तो आपकी नाड़ियाँ शुद्ध रहती हैं और 'नाद योग' (Sound Healing) का प्रभाव शरीर पर शीघ्र होता है।",
    ab_art_h2: "दैनिक पद-यात्रा (Daily Steps & Walking)",
    ab_art_p3: "आधुनिक विज्ञान और प्राचीन आयुर्वेद दोनों यह प्रमाणित करते हैं कि नियमित पद-यात्रा (चलना) हृदय और पाचन तंत्र के लिए अमृत के समान है। ब्रह्म मुहूर्त में की गई पद-यात्रा से मस्तिष्क को शुद्ध प्राणवायु (Oxygen) प्राप्त होती है, जिससे मानसिक तनाव और नकारात्मक ऊर्जा का नाश होता है। अपने शारीरिक सूचकांक (BMI) के आधार पर 7,000 से 10,000 कदम प्रतिदिन अवश्य चलना चाहिए।",    
        
// 🔱 ADD THESE MISSING KEYS FOR SOUND MODULE
status_locked: "🔐 लॉक है",
status_unlocked: "🔓 अनलॉक",
raag_sun: "दीपक / बिलावल",
raag_moon: "खमाज / भैरवी",
raag_mars: "भैरव / मारवा",
raag_mercury: "सारंग / मेघ",
raag_jupiter: "दरबारी / तोड़ी",
raag_venus: "यमन / खमाज",
raag_saturn: "भीमपलासी / मालकौंस",
raag_rahu: "छायानट",
raag_ketu: "ललित",

        shop_title: "महादेव एस्ट्रोलॉजर स्टोर",
        shop_subtitle: "100% प्रामाणिक आध्यात्मिक एवं आयुर्वेदिक उत्पाद",
        fssai_reg: "✔ FSSAI पंजीकृत",
        lab_cert: "✔ लैब प्रमाणित",
        vedic_energized: "✔ वैदिक अभिमंत्रित",
        divine_store: "दिव्य भंडार",
        cat_gemstones: "रत्न (Gemstones)",
        cat_rudraksha: "रुद्राक्ष (Rudraksha)",
        cat_herbs: "हर्बल वेलनेस",
        cat_energy_kits: "ऊर्जा किट",
        how_to_order_title: "ऑर्डर कैसे करें",
        step_01_label: "01. श्रेणी चुनें:",
        step_01_desc: "रत्न, रुद्राक्ष या जड़ी-बूटियों में से चुनाव करें।",
        step_02_label: "02. व्हाट्सएप पूछताछ:",
        step_02_desc: "सीधे हमसे बात करने के लिए 'ऑर्डर' बटन पर क्लिक करें।",
        step_03_label: "03. सुरक्षित भुगतान:",
        step_03_desc: "चयन के बाद UPI या बैंक ट्रांसफर के माध्यम से भुगतान करें।",
        step_04_label: "04. तेज़ डिलीवरी:",
        step_04_desc: "3-5 दिनों में अपना सिद्ध उत्पाद प्राप्त करें।",
   }
};

/**
 * 🔱 MAHADEV ASTROLOGER MA - TRANSLATION ENGINE (V-MAX)
 * Architecture: 2 Levels (Common + Dynamic Folder Translation)
 */
(function() {
    // ⚠️ FIXED: Changed 'selectedLanguage' to 'selectedLang' and default to 'en' for AdSense safety
    const lang = localStorage.getItem('selectedLang') || 'en';
    document.documentElement.lang = lang;

    // 🧠 1. SMART MERGER: मास्टर डिक्शनरी बनाने का फंक्शन
    function getMasterDictionary(currentLang) {
        let dict = Object.assign({}, window.commonTranslations?.[currentLang] || {});
        
        // यह लूप स्वयं ही आपके फोल्डर-लेवल डिक्शनरी को खोज लेगा
        for (let key in window) {
            if (key !== 'commonTranslations' && key.includes('Translation') && typeof window[key] === 'object') {
                if (window[key][currentLang]) {
                    Object.assign(dict, window[key][currentLang]);
                }
            }
        }
        return dict;
    }
    
    // 🛡️ 2. PRE-PAINT INTERCEPTOR (FOUC / Text Flashing को रोकने हेतु)
    // अगर यूज़र ने 'hi' चुना है, तभी यह ऑब्जर्वर चलेगा
    if (lang === 'hi') {
        const observer = new MutationObserver((mutations) => {
            const dict = getMasterDictionary(lang);
            
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === 1) { 
                        // स्वयं टैग को जांचें
                        if (node.hasAttribute('data-key')) {
                            const text = dict[node.getAttribute('data-key')];
                            if (text) node.innerHTML = text;
                        }
                        // बच्चों (children) को जांचें
                        if (node.querySelectorAll) {
                            node.querySelectorAll('[data-key]').forEach(child => {
                                const text = dict[child.getAttribute('data-key')];
                                if (text) child.innerHTML = text;
                            });
                        }
                    }
                });
            });
        });
        
        // HTML रेंडर होने से पूर्व ही शब्दों को बदल दें
        observer.observe(document.documentElement, { childList: true, subtree: true });
    }
    
    // ⚙️ 3. MANUAL SWITCHER (बटन क्लिक के लिए ग्लोबल फंक्शन)
    window.updateAllTranslations = function() {
        // ⚠️ FIXED: Changed 'selectedLanguage' to 'selectedLang'
        const currentLang = localStorage.getItem('selectedLang') || 'en';
        document.documentElement.lang = currentLang;

        const masterDictionary = getMasterDictionary(currentLang);

        document.querySelectorAll('[data-key]').forEach(el => {
            const key = el.getAttribute('data-key');
            const translatedText = masterDictionary[key];

            if (translatedText) {
                if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
                    if (el.type === "submit" || el.type === "button") {
                        if (el.value !== translatedText) el.value = translatedText;
                    } else {
                        if (el.placeholder !== translatedText) el.placeholder = translatedText;
                    }
                } else {
                    if (el.innerHTML !== translatedText) el.innerHTML = translatedText;
                }
            }
        });

        // Title Sync
        let pageKey = document.body.getAttribute('data-page');
        const titleKeys = { 
            'herbal': 'herb_page_title', 
            'puja': 'puja_page_title', 
            'rudraksha': 'rudra_page_title', 
            'gemstones': 'gem_title', 
            'shop': 'shop_title', 
            'panchang': 'ins_panchang_title',
            'about': 'title_about',
            'contact': 'contact_page_title'
        };
        
        if (pageKey && titleKeys[pageKey] && masterDictionary[titleKeys[pageKey]]) {
            document.title = masterDictionary[titleKeys[pageKey]];
        }
    };
})();
